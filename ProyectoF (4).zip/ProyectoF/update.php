<?php
include("db_conn.php");
$id=$_GET['id'];
$sql= "SELECT *FROM datos WHERE id='$id'";
$query=mysqli_query($conn,$sql);
$row =mysqli_fetch_array($query);
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Usuario</title>
    <link rel="stylesheet" href="stylesRegistro.css">
    
</head>
<body>
    <h1 class="title2">Autobuses Laguneros</h1>
    <input type="button" class="button3" onclick="history.back()" value="Regresar">
   <div class="container">
    <div class="title">Editar Usuario</div>
        <form action="edit_user.php" method="POST">
            <div class="user-details">
                <input type="hidden" name="id" value="<?= $row['id']?>">
                <div class="input-box">
                    <span class="details">Username</span>
                    <input type="text" name="username" placeholder="Ingresa tu nombre de usuario" value="<?= $row['username']?>"required>
                </div>
                <div class="input-box">
                    <span class="details">Correo Electronico</span>
                    <input type="text" name="correo" placeholder="Ingresa tu correo" value="<?= $row['correo']?>" required>
                </div>
                <div class="input-box">
                    <span class="details">Telefono</span>
                    <input type="text" name="telefono" placeholder="Ingresa tu telefono" value="<?= $row['telefono']?> "required>
                </div>
                <div class="input-box">
                    <span class="details">Contraseña</span>
                    <input type="text" name="contra" placeholder="Ingresa tu contraseña" value="<?= $row['contra']?>" required>
                </div>
                <input type="hidden" name="fecha" value="<?= $row['fecha']?>">
                
            </div>
            <div class="button">
                <input type="submit"  value="Actualizar">
               
            </div>
            
        </form>
        
        
   </div>
  
</body>
</html>