<?php
    include("conexion.php");

    if(isset($_POST['register'])){
        if(
            strlen($_POST['username'])>=1 &&
            strlen($_POST['correo'])>=1 &&
            strlen($_POST['telefono'])>=1 &&
            strlen($_POST['contra'])>=1
            ){
                $username=trim($_POST['username']);
                $correo=trim($_POST['correo']);
                $telefono=trim($_POST['telefono']);
                $contra=trim($_POST['contra']);
                $fecha= date("d/m/y");
                $consulta="INSERT INTO datos(username,correo,telefono,contra,fecha)
                            VALUES('$username','$correo','$telefono','$contra','$fecha')";
                $resultado=mysqli_query($mysqli,$consulta);
                if($resultado){
                ?>
                    <h3 class="success">Tu registro se a completado</h3>
                <?php
                }else{
                 ?>
                    <h3 class="error">Ocurrio un error</h3>
                 <?php
                }    
            }else{
            ?>
             <h3 class="error"> Llena todos los campos</h3>
            <?php
        }
    }

?>