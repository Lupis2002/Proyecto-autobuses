<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Autobuses Laguneros</title>
    <link rel="stylesheet" href="style.css">
    
</head>
<body>
    
    <header class="header">

        <div class="menu container">
            <a href="#" class="logo">Autobuses Laguneros</a>
            <input type="checkbox" id="menu">
            <label for="menu">
                <img src="images/menu.png" class="menu-icono" alt="">
            </label>

            <nav class="navbar">
                <ul>
                
                    <li><a href='logout.php'>Cerrar Sesion</a></li>                
                    <li><a href="empleo.html">Bolsa de Trabajo</a></li>
                    <li><a href="#destinos">Destinos</a></li>
                    <li><a href="nuestrogpo.html">Nosotros</a></li>
                </ul>
            </nav>

        </div>

        <div class="header-content container">
            <div class="header-txt">
                <h1>Ahora es mas facil <span> viajar</span> a tu destino favorito</h1>
                <p>
                    Reserva tu viaje con nostros y vive de una experiencia de primera clase.
                </p>
                <a href="#" class="btn-1">Informacion</a>
            </div>
        </div>

    </header>

    <section class="about container">   
        <div class="about-img">
            <img src="images/b1.jpg" alt="">
            <img src="images/b2.jpg" alt="">
        </div>

        <div class="about-txt">
            <h2>Viajar con nosotros es la <span> mejor</span> experiencia</h2>
            <p>
                Todos los destinos turisticos estan con nosotros.
            </p>
            <a href="" class="btn-1">Informacion</a>
        </div>
    </section>

    <!--MAIN-->

    <main class="products container">
        <a name="destinos"></a>
        <h2>Nuestros <span>destinos</span></h2>

        <div class="products-content">
            <div class="product">
                <img src="images/1.jpg" alt="">
                <div class="product-txt">
                    <h3>Chichen Itza</h3>
                    <p>
                        Visita y queda fascinado con una de las 7 maravillas del mundo...
                    </p>
                    <a href="reservar.html" class="btn-2">Reservar</a>
                </div>
            </div>

            <div class="product">
                <img src="images/2.jpg" alt="">
                <div class="product-txt">
                    <h3>Los Cabos</h3>
                    <p>
                        Sumergete y disfruta de unas lindas vaciones en familia...
                    </p>
                    <a href="reservar.html" class="btn-2">Reservar</a>
                </div>
            </div>

            <div class="product">
                <img src="images/3.jpg" alt="">
                <div class="product-txt">
                    <h3>Ciudad de Mexico</h3>
                    <p>
                        Visita todos los centros turisticos que brinda la capital...
                    </p>
                    <a href="reservar.html" class="btn-2">Reservar</a>
                </div>
            </div>

            <div class="product">
                <img src="images/4.jpg" alt="">
                <div class="product-txt">
                    <h3>Mazatlan</h3>
                    <p>
                        Vive un fin de semana espectacular en la isla de la Piedra...
                    </p>
                    <a href="reservar.html" class="btn-2">Reservar</a>
                </div>
            </div>

            <div class="product">
                <img src="images/5.jpg" alt="">
                <div class="product-txt">
                    <h3>Guadalajara</h3>
                    <p>
                        Visita la ciudad mas importante de Jalisco y dislumbrate con su bellezza...
                    </p>
                    <a href="reservar.html" class="btn-2">Reservar</a>
                </div>
            </div>

            <div class="product">
                <img src="images/6.jpg" alt="">
                <div class="product-txt">
                    <h3>Monterrey</h3>
                    <p>
                        Conoce una de las ciudades mas importante de nuestro pais...
                    </p>
                    <a href="reservar.html" class="btn-2">Reservar</a>
                </div>
            </div>

            <div class="product">
                <img src="images/7.jpg" alt="">
                <div class="product-txt">
                    <h3>Cancun</h3>
                    <p>
                        Vive de una semana fascinante con tu familia en aguas cristalinas...
                    </p>
                    <a href="reservar.html" class="btn-2">Reservar</a>
                </div>
            </div>

            <div class="product">
                <img src="images/8.jpg" alt="">
                <div class="product-txt">
                    <h3>Veracruz</h3>
                    <p>
                        Visita uno de los puertos mas turisticos de nuestro pais...
                    </p>
                    <a href="reservar.html" class="btn-2">Reservar</a>
                </div>
            </div>

            <div class="product">
                <img src="images/9.jpg" alt="">
                <div class="product-txt">
                    <h3>Chihuahua</h3>
                    <p>
                        Deslumbrate con una de las ciudades mas bonitas en nuestro pais...
                    </p>
                    <a href="reservar.html" class="btn-2">Reservar</a>
                </div>
            </div>

            <div class="product">
                <img src="images/guanajuato.jpg" alt="">
                <div class="product-txt">
                    <h3>Guanajuato</h3>
                    <p>
                        Visita una de las ciudades coloniales mas bonitas de nuestro pais...
                    </p>
                    <a href="reservar.html" class="btn-2">Reservar</a>
                </div>
            </div>

            <div class="product">
                <img src="images/acapulco.jpg" alt="">
                <div class="product-txt">
                    <h3>Acapulco</h3>
                    <p>
                        Visita una de las playas mas visitadas de nuestro pais...
                    </p>
                    <a href="reservar.html" class="btn-2">Reservar</a>
                </div>
            </div>

            <div class="product">
                <img src="images/chiapas.jpg" alt="">
                <div class="product-txt">
                    <h3>Chiapas</h3>
                    <p>
                        Visita y recorre en lancha el Cañon del Sumidero...
                    </p>
                    <a href="reservar.html" class="btn-2">Reservar</a>
                </div>
            </div>

            <div class="product">
                <img src="images/tijuana.jpg" alt="">
                <div class="product-txt">
                    <h3>Tijuana</h3>
                    <p>
                        Visita la ciudad mas divertida del mundo mundial
                    </p>
                    <a href="reservar.html" class="btn-2">Reservar</a>
                </div>
            </div>

 	        <div class="product">
                <img src="images/juarez.jpg" alt="">
                <div class="product-txt">
                    <h3>Ciudad Juarez</h3>
                    <p>
                        Visita una de las fronteras mas famosas de México
                    </p>
                    <a href="reservar.html" class="btn-2">Reservar</a>
                </div>
            </div>


	        <div class="product">
                <img src="images/torreon.jpg" alt="">
                <div class="product-txt">
                    <h3>Torreon</h3>
                    <p>
                       Ven y pasa unas increíbles vacaciones con toda la familia
                    </p>
                    <a href="reservar.html" class="btn-2">Reservar</a>
                </div>
            </div>

        </div>   
    </main>

    <section class="information">
        
        <div class="information-content container">
            <div class="information-1"></div>
            <div class="information-2">
                <h2>Tenemos los <span>mejores</span> planes y ofertas</h2>
                <p>
                    Los mejores precios los tenemos nosotros.
                </p>
                
                <div class="img-content">
                    <img src="images/sec-1.jpg" alt="">
                    <img src="images/sec-2.jpg" alt="">
                    <img src="images/sec-3.jpg" alt="">
                </div>
            </div>
        </div>
    </section>

    <section class="contact container">
        <h2>Contacto</h2>
        <form>
            <input type="email" placeholder="Correo">
            <input type="submit" value="enviar" class="btn-3">
        </form>
    </section>

    <footer class="footer">
        <div class="footer-content container">
            <div class="link">
                <h3>Terminos y condiciones</h3>
                <ul>
                    <li><a href="#">Devoluciones</a></li>
                    <li><a href="#">Cambios de boleto</a></li>
                    <li><a href="#">Pagos con Tarjeta</a></li>
                    <li><a href="facturacion.html">Facturacion</a></li>
                </ul>
            </div>
            <div class="link">
                <h3>Visitanos en redes sociales</h3>
                <ul>
                    <li><a href="#">Instagram</a></li>
                    <li><a href="#">Facebook</a></li>
                    <li><a href="#">X</a></li>
                    <li><a href="#">WhatsApp</a></li>
                </ul>
            </div>
            <div class="link">
                <h3>Recientes</h3>
                <ul>
                    <li><a href="#">Los mejores destinos en Mexico</a></li>
                    <li><a href="#">Destinos que manejamos</a></li>
                    <li><a href="#">Atracciones en Mazatlan</a></li>
                    <li><a href="#">Boletos de Avion</a></li>
                </ul>
            </div>
        </div>
    </footer>

</body>
</html>