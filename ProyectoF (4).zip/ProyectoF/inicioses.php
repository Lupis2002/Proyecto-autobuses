<?php
    require 'database.php';

    session_start();

    if(isset($_GET['cerrar_sesion'])){
        session_unset();

        session_destroy();
    }

    if(isset($_SESSION['rol'])){
        switch($_SESSION['rol']){
            case '1':
                header('location: admin.php');
            break;

            case '2':
            header('location: index2.html');
            break;

            default:
        }
    }

    if(isset($_POST['uname']) && isset($_POST['password'])){
        $username = $_POST['uname'];
        $password = $_POST['password'];

        
        $db = new Database();
        $query = $db->connect()->prepare('SELECT*FROM users WHERE username = :uname AND contra = :password');
        $query->execute(['uname' => $username, 'password' => $password]);

		
        $row = $query->fetch(PDO::FETCH_NUM);
        if($row == true){
            // validar rol
            $rol = $row[4];
            $_SESSION['rol'] = $rol;

            switch($_SESSION['rol']){
                case '1':
                    header('location: admin.php');
                break;
    
                case '2':
                header('location: index2.php');
                break;
    
                default:
            }
        }else{
            // no existe el usuario
            echo "El usuario o contraseña son incorrectos";
        }

    }
    

?>
<!DOCTYPE html>
<html>
<head>
	<title>LOGIN</title>
	<link href="styless.css" rel="stylesheet">
</head>
<body>
     <form action="inicioses.php" method="post">	 
     	<h2>LOGIN</h2>
		     	
     	<label>User Name</label>
     	<input type="text" name="uname" placeholder="User Name"><br>

     	<label>Password</label>
     	<input type="password" name="password" placeholder="Password"><br>
		 
     	<button type="submit">Login</button>
		<a href='registro.php' type="button">Registrarme</a>
     </form>
</body>
</html>
